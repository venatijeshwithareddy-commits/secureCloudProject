function login() {
    let username = document.getElementById("username").value;

    if (username.trim() === "") {
        alert("Please enter a username");
        return;
    }

    document.getElementById("loginMsg").innerHTML =
        "Welcome, " + username + "!";
}

async function uploadFile() {

    let file = document.getElementById("fileInput").files[0];

    if (!file) {
        alert("Please select a file");
        return;
    }

    try {

        const response = await fetch("/api/message");
        const data = await response.json();

        let shareLink =
            "https://cloudshare.com/file/" +
            Math.floor(Math.random() * 100000);

        let fileCard = document.createElement("div");
        fileCard.className = "file-card";

        fileCard.innerHTML = `
            <h3>${file.name}</h3>
            <p>${data.message}</p>

            <p><strong>File Size:</strong> ${(file.size / 1024).toFixed(2)} KB</p>

            <p><strong>Secure Share Link:</strong></p>

            <input type="text"
                   value="${shareLink}"
                   id="link${Date.now()}"
                   readonly
                   size="40">

            <br><br>

            <button onclick="copyLink('${shareLink}')">
                Copy Link
            </button>
        `;

        document.getElementById("fileList").appendChild(fileCard);

    } catch (error) {
        alert("Backend connection failed");
        console.error(error);
    }
}

function copyLink(link) {

    navigator.clipboard.writeText(link)
        .then(() => {
            alert("Link copied successfully!");
        })
        .catch(() => {
            alert("Unable to copy link");
        });
}